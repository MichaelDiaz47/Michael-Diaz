//=============================================================================
// PROGRAMMER: Michael Diaz
// PANTHER ID: 6454427
//
// CLASS: COP2210
// SECTION: Your class section: example U01
// SEMESTER: Fall 2023
// CLASSTIME:T/TH 9:30am-12:15pm
//
// Project:Project 1
// DUE: October 22,2023 at 11:59pm
//
// CERTIFICATION: I understand FIU’s academic policies, and I certify that this work is my
// own and that none of it is the work of any other person.
//=============================================================================
package app;

import food.Apple;
import food.Sandwich;
import machine.Register;
import transactions.Payment;

public class Controller {
    public static void main(String[] args){
        System.out.println("===============================================");
        System.out.println("COP 2210 - Project 1 Output");
        System.out.println("Michael Diaz");
        System.out.println("Panther iD: 6454427");
        System.out.println("Your Class Sections here ");
        System.out.println("===============================================");
        System.out.println("\n");

        Register register = new Register(15,20,10,20,50);
        register.cashInfo("Manager");
        register.cashInfo("Staff");

        Apple grannySmith = new Apple("Granny Smith",1.51,140);
        grannySmith.displayInfo();
        Payment applePayment1 = new Payment(10,0,0,0,47);
        applePayment1.displayInfo();
        register.buyApple(grannySmith,applePayment1);
        register.cashInfo("Manager");
        Apple macintosh = new Apple("Macintosh",1.70,150);
        macintosh.displayInfo();
        Payment applePayment2 = new Payment(0,2,0,0,0);
        applePayment2.displayInfo();
        register.buyApple(macintosh,applePayment2);
        register.cashInfo("Manager");



        //step 9b
        Sandwich sandwich = new Sandwich(true,true,true);
        sandwich.displayInfo();
        Payment sandwichPayment1 = new Payment(5,2,1,1,2);
        sandwichPayment1.displayInfo();
        register.buySandwich(sandwich,sandwichPayment1);
        register.cashInfo("Manager");

        boolean meat = true;
        boolean cheese = true;
        boolean veggies = true;

        System.out.println("");

      for(int row = 1;row<=8;row++){
          if (row <= 4) {
              meat = true;
          } else{
              meat = false;
          }if(row == 1 || row == 2 || row == 5 || row == 6){
              cheese = true;
          }else{
              cheese = false;
          }if(row%2 ==1){
              veggies = true;
          }else{
              veggies = false;
          }
          Sandwich s = new Sandwich(meat,cheese,veggies);
          Payment p = new Payment(10,0,0,0,0);
          System.out.printf("\n");
          System.out.println("===========================================================");
          System.out.println("===========================================================");
          s.displayInfo();
          p.displayInfo();
          register.buySandwich(s,p);
          register.cashInfo("Manager");
          System.out.println("===========================================================");
          System.out.println("===========================================================");
      }
    }//end main
}//end Controller
