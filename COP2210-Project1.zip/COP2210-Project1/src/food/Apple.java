package food;

public class Apple {
    // Instant variables
    private String type;
    private double weight;
    private double pricePerWeight;


    //Constructor
    public Apple(String type,
                 double pricePerWeight,
                 double weightInGrams) {
        this.type = type;
        this.pricePerWeight = pricePerWeight;
        this.weight = weightInGrams * 0.00220;
    }

    public String getType(){
        return type;
    }
    public double getWeight(){
        return weight;
    }
    public double getPricePerWeight(){
        return pricePerWeight;
    }
    public void setPricePerWeight(double pricePerWeight, String personal){
        this.pricePerWeight = pricePerWeight;
    }

    public void displayInfo(){
        System.out.println("==========================================");
        System.out.println("Apple Info");
        System.out.println("==========================================");
        System.out.printf("Type:\t\t\t\t\t\t %-15s\n", type);
        System.out.printf("Weight:\t\t\t\t\t\t %-6.4f lbs\n", weight);
        System.out.printf("Price Per Unit:\t\t\t\t %-10.2f\n", pricePerWeight);
        System.out.printf("Price:\t\t\t\t\t\t $%-15.2f\t\n",price());
        System.out.println("");
    }

    public double price(){
        double price = weight * pricePerWeight;
        return price;
    }

}//end Apple
